<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class = "mphb-required-fields-tip">
	<small>
		<?php esc_html_e( 'Required fields are followed by', 'motopress-hotel-booking' ); ?>
		<abbr title="required">*</abbr>
	</small>
</p>