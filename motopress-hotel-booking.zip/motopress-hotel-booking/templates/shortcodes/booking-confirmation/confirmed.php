<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Your booking is confirmed. Thank You!', 'motopress-hotel-booking' ); ?>
</p>