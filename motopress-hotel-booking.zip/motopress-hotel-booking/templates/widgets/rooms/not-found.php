<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

esc_html_e( 'Nothing found.', 'motopress-hotel-booking' );