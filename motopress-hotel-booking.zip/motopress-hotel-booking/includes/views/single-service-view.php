<?php

namespace MPHB\Views;

class SingleServiceView {

	const TEMPLATE_CONTEXT = 'single-service';

	public static function renderPrice(){
		mphb_get_template_part( static::TEMPLATE_CONTEXT . '/price' );
	}

	public static function _renderMetas(){
		self::renderPrice();
	}



}
